﻿namespace part_1
{
    public class create_instance_and_tables
    {
    }
}
