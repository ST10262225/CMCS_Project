﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.AspNetCore.Mvc;
using part_1.Models;
using System.IO;

namespace part_1.Controllers
{
    public class ClaimsController : Controller
    {
        [HttpPost]
        public IActionResult GenerateInvoice([FromBody] get_cliams data)
        {
            using (var stream = new MemoryStream())
            {
                // Initialize the PDF writer and document
                Document document = new Document();
                PdfWriter writer = PdfWriter.GetInstance(document, stream);
                document.Open();
                //int count = data.no;
                // Adding content to the PDF
                document.Add(new Paragraph($"Invoice for Claim No: {data.no}"));
                document.Add(new Paragraph($"Username: {data.username}"));
                document.Add(new Paragraph($"Module: {data.module}"));
                document.Add(new Paragraph($"Claim Date: {data.claim_date}"));
                document.Add(new Paragraph($"Period: {data.period}"));
                document.Add(new Paragraph($"Hours Worked: {data.hours_worked}"));
                document.Add(new Paragraph($"Hour Rate: {data.hour_rate}"));
                document.Add(new Paragraph($"Total: {data.total}"));
                document.Add(new Paragraph($"Description: {data.description}"));

                // Close the document to finalize the PDF content
                document.Close();

                // Ensure the stream position is at the beginning
                stream.Position = 0;

                // Return the PDF as a file result
                return File(stream.ToArray(), "application/pdf", $"Invoice_{data.no}.pdf");
            }
        }

        public class ClaimData
        {
            public string no { get; set; }
            public string username { get; set; }
            public string module { get; set; }
            public string claimDate { get; set; }
            public string period { get; set; }
            public string hoursWorked { get; set; }
            public string hourRate { get; set; }
            public string total { get; set; }
            public string description { get; set; }
        }
    }
}
