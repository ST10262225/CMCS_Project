﻿using System.ComponentModel.DataAnnotations;

namespace part_1.Models
{
    public class registers
    {
           
            public string Username { get; set; }

            public string FullName { get; set; }

            public string Email { get; set; }

          
            public string Role { get; set; }

         
            public string Module { get; set; }

            public string Password { get; set; }
        

    }
}
