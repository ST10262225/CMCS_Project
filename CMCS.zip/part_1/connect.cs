﻿namespace part_1
{
    public class connect
    {

        public string connecting()
        {

            //then return connection
            return "Data Source=(localdb)\\claim_system;Initial Catalog=claiming_system;";
        }
    }
}
